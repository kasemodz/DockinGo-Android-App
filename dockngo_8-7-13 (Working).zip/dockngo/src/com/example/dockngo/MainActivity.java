package com.example.dockngo;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;

public class MainActivity extends Activity {
	private GoogleMap mMaps;
	public ActionBar ActionBar; 
    @Override
    public void onCreate(Bundle savedInstanceState) {    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ActionBar = getActionBar();
//        ActionBar.setSubtitle("DockNGo");
//        ActionBar.setTitle("Diy-Create.com");
        setUpMapIfNeeded();  
        mMaps.setMyLocationEnabled(true);
        //UiSettings.setMyLocationButtonEnabled(true);
    // mMaps =  ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
       // mMaps.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        
        
    }
    


private void setUpMapIfNeeded() {
    // Do a null check to confirm that we have not already instantiated the map.
    if (mMaps == null) {
        mMaps = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
                            .getMap();
        // Check if we were successful in obtaining the map.
        if (mMaps != null) {
            // The Map is verified. It is now safe to manipulate the map.

        }
    }
}

public boolean onCreateOptionsMenu(Menu menu) {
	MenuInflater inflater = getMenuInflater();
    inflater.inflate(R.menu.main, menu);
    return super.onCreateOptionsMenu(menu);
}
public boolean onOptionsItemSelected(MenuItem item) {
	// TODO Auto-generated method stub
	switch (item.getItemId()) {
	case R.id.action_play:
		//do something when this button is pressed
		return true;
	case R.id.action_pause:
		//do something when this button is pressed
		return true;
	case R.id.action_prev:
		//do something when this button is pressed
		return true;
	case R.id.action_next:
		//do something when this button is pressed
		return true;
	default: 
		return true;
	}
}
}